//root -l 'tgtRatePlots.C(21)'
#include <TROOT.h>
#include <TTree.h>
#include <TH1.h>
#include <TH2.h>
#include <TFile.h>
#include <TF1.h>
#include <TStyle.h>
#include <TColor.h>
#include <TGaxis.h>
#include <TCanvas.h>
#include <TPaveLabel.h>
#include <TPaveText.h>
#include <TGraphErrors.h>

const float pi = 3.1415926;

int analysis(int angle)  
{

  //Define parameters common to all analysis configurations

  const Int_t points = 2048;
  const Int_t files = 38;
  const int std = 1; //file index (starts with 0) for NIST standard run

  char printname[256];
  char graphname1[256];
  char xTitle[256];
  char yTitle[256];
  char GraphText1[256];
  char histTitle[256];

  char output_line[256];

  gStyle->SetStatColor(0);//All this stuff makes backgrounds, etc.
  gStyle->SetTitleColor(0);//transparent for printing purposes...
  gStyle->SetCanvasColor(0);
  gStyle->SetPadColor(0);
  gStyle->SetPadBorderMode(0);
  gStyle->SetCanvasBorderMode(0);
  gStyle->SetFrameBorderMode(0);
  gStyle->SetPalette(1);
  //gStyle->SetOptDate(1);
  //  gStyle->SetOptStat(kFALSE);
  gStyle->SetOptStat(11);
  gStyle->SetOptFit(1111);
  gStyle->SetPadGridX(kTRUE);
  gStyle->SetPadGridY(kTRUE);
  
  TGaxis::SetMaxDigits(3);

  //Open Input file which stores reflectivity data

  char INPUT_FILENAME[files][256];
  sprintf(INPUT_FILENAME[0],"data/nist_noAverage.txt"); // 90 deg
  //sprintf(INPUT_FILENAME[0],"../03Apr2016/data/nist2.txt"); // 90 deg
  //sprintf(INPUT_FILENAME[0],"../IACrun1/data_day2/nist1_5_50.txt"); // 90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[0]);
  ifstream myInFile0(INPUT_FILENAME[0]);

  sprintf(INPUT_FILENAME[1],"data/NIST.txt"); // 90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[1]);
  ifstream myInFile1(INPUT_FILENAME[1]);

  sprintf(INPUT_FILENAME[2],"data/blackback_mylar.txt"); //90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[2]);
  ifstream myInFile2(INPUT_FILENAME[2]);

  sprintf(INPUT_FILENAME[3],"data/my2milMylar.txt"); //90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[3]);
  ifstream myInFile3(INPUT_FILENAME[3]);

  sprintf(INPUT_FILENAME[4],"data/my1milMylar.txt"); //90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[4]);
  ifstream myInFile4(INPUT_FILENAME[4]);

  sprintf(INPUT_FILENAME[5],"data/alFoil.txt"); //90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[5]);
  ifstream myInFile5(INPUT_FILENAME[5]);

  sprintf(INPUT_FILENAME[6],"data/alFoil_dullside.txt"); // 90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[6]);
  ifstream myInFile6(INPUT_FILENAME[6]);

  sprintf(INPUT_FILENAME[7],"data/anoluxI.txt"); //90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[7]);
  ifstream myInFile7(INPUT_FILENAME[7]);

  sprintf(INPUT_FILENAME[8],"data/miroIV.txt"); //90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[8]);
  ifstream myInFile8(INPUT_FILENAME[8]);

  sprintf(INPUT_FILENAME[9],"data/miroSun.txt"); //90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[9]);
  ifstream myInFile9(INPUT_FILENAME[9]);

  sprintf(INPUT_FILENAME[10],"data/whitelight92.txt"); //90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[10]);
  ifstream myInFile10(INPUT_FILENAME[10]);

  sprintf(INPUT_FILENAME[11],"data/2000Ag.txt"); //90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[11]);
  ifstream myInFile11(INPUT_FILENAME[11]);

  sprintf(INPUT_FILENAME[12],"data/uvs.txt"); //90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[12]);
  ifstream myInFile12(INPUT_FILENAME[12]);

  sprintf(INPUT_FILENAME[13],"data/uvs_noInt.txt"); //90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[13]);
  ifstream myInFile13(INPUT_FILENAME[13]);

  sprintf(INPUT_FILENAME[14],"data/bogdanMylar.txt"); //90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[14]);
  ifstream myInFile14(INPUT_FILENAME[14]);

  sprintf(INPUT_FILENAME[15],"data/bogdanMylar_low.txt"); //90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[15]);
  ifstream myInFile15(INPUT_FILENAME[15]);

  sprintf(INPUT_FILENAME[16],"data/bogdanMylar_high.txt"); //90 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[16]);
  ifstream myInFile16(INPUT_FILENAME[16]);

  sprintf(INPUT_FILENAME[17],"data/bogdanMylar_60.txt"); //60 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[17]);
  ifstream myInFile17(INPUT_FILENAME[17]);

  sprintf(INPUT_FILENAME[18],"data/bogdanMylar_45.txt"); //45 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[18]);
  ifstream myInFile18(INPUT_FILENAME[18]);

  sprintf(INPUT_FILENAME[19],"data/bogdanMyar_30.txt"); //30 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[19]);
  ifstream myInFile19(INPUT_FILENAME[19]);

  sprintf(INPUT_FILENAME[20],"data/anoluxI_60.txt"); //60 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[20]);
  ifstream myInFile20(INPUT_FILENAME[20]);

  sprintf(INPUT_FILENAME[21],"data/anoluxI_45.txt"); //45 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[21]);
  ifstream myInFile21(INPUT_FILENAME[21]);

  sprintf(INPUT_FILENAME[22],"data/anoluxI_30.txt"); //30 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[22]);
  ifstream myInFile22(INPUT_FILENAME[22]);

  sprintf(INPUT_FILENAME[23],"data/miro4270_60.txt"); //60 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[23]);
  ifstream myInFile23(INPUT_FILENAME[23]);

  sprintf(INPUT_FILENAME[24],"data/miro4270_45.txt"); //45 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[24]);
  ifstream myInFile24(INPUT_FILENAME[24]);

  sprintf(INPUT_FILENAME[25],"data/miro4270_30.txt"); //30 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[25]);
  ifstream myInFile25(INPUT_FILENAME[25]);

  sprintf(INPUT_FILENAME[26],"data/miroIV_60.txt"); //60 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[26]);
  ifstream myInFile26(INPUT_FILENAME[26]);

  sprintf(INPUT_FILENAME[27],"data/miroIV_45.txt"); //45 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[27]);
  ifstream myInFile27(INPUT_FILENAME[27]);

  sprintf(INPUT_FILENAME[28],"data/miroIV_30.txt"); //30 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[28]);
  ifstream myInFile28(INPUT_FILENAME[28]);

  sprintf(INPUT_FILENAME[29],"data/my1milMylar_60.txt"); //60 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[29]);
  ifstream myInFile29(INPUT_FILENAME[29]);

  sprintf(INPUT_FILENAME[30],"data/my1milMylar_45.txt"); //45 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[30]);
  ifstream myInFile30(INPUT_FILENAME[30]);

  sprintf(INPUT_FILENAME[31],"data/my1milMylar_30.txt"); //30 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[31]);
  ifstream myInFile31(INPUT_FILENAME[31]);

  sprintf(INPUT_FILENAME[32],"data/bogdanMylar_60b.txt"); //45 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[32]);
  ifstream myInFile32(INPUT_FILENAME[32]);

  sprintf(INPUT_FILENAME[33],"data/bogdanMylar_45b.txt"); //45 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[33]);
  ifstream myInFile33(INPUT_FILENAME[33]);

  sprintf(INPUT_FILENAME[34],"data/bogdanMylar_30b.txt"); //45 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[34]);
  ifstream myInFile34(INPUT_FILENAME[34]);

  sprintf(INPUT_FILENAME[35],"data/alFoil_60.txt"); //45 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[35]);
  ifstream myInFile35(INPUT_FILENAME[35]);

  sprintf(INPUT_FILENAME[36],"data/alFoil_45.txt"); //45 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[36]);
  ifstream myInFile36(INPUT_FILENAME[36]);

  sprintf(INPUT_FILENAME[37],"data/alFoil_30.txt"); //45 deg
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAME[37]);
  ifstream myInFile37(INPUT_FILENAME[37]);

  float lambda[files][points], counts[files][points];
  float dummyError[points];
  float statError[files][points];
  char header[256];
  for(int h = 0; h<57; h++) { //read the header info
    myInFile0 >> header;
    myInFile1 >> header;
    myInFile2 >> header;
    myInFile3 >> header;
    myInFile4 >> header;
    myInFile5 >> header;
    myInFile6 >> header;
    myInFile7 >> header;
    myInFile8 >> header;
    myInFile9 >> header;
    myInFile10 >> header;
    myInFile11 >> header;
    myInFile12 >> header;
    myInFile13 >> header;
    myInFile14 >> header;
    myInFile15 >> header;
    myInFile16 >> header;
    myInFile17 >> header;
    myInFile18 >> header;
    myInFile19 >> header;
    myInFile20 >> header;
    myInFile21 >> header;
    myInFile22 >> header;
    myInFile23 >> header;
    myInFile24 >> header;
    myInFile25 >> header;
    myInFile26 >> header;
    myInFile27 >> header;
    myInFile28 >> header;
    myInFile29 >> header;
    myInFile30 >> header;
    myInFile31 >> header;
    myInFile32 >> header;
    myInFile33 >> header;
    myInFile34 >> header;
    myInFile35 >> header;
    myInFile36 >> header;
    myInFile37 >> header;

    //cout << header[h] << endl;
  }
  //cout << "Wavelength (nm) 	Counts" << endl;
  for(int i=0;i<points;i++) {
    myInFile0 >> lambda[0][i] >> counts[0][i];
    myInFile1 >> lambda[1][i] >> counts[1][i];
    myInFile2 >> lambda[2][i] >> counts[2][i];
    myInFile3 >> lambda[3][i] >> counts[3][i];
    myInFile4 >> lambda[4][i] >> counts[4][i];
    myInFile5 >> lambda[5][i] >> counts[5][i];
    myInFile6 >> lambda[6][i] >> counts[6][i];
    myInFile7 >> lambda[7][i] >> counts[7][i];
    myInFile8 >> lambda[8][i] >> counts[8][i];
    myInFile9 >> lambda[9][i] >> counts[9][i];
    myInFile10 >> lambda[10][i] >> counts[10][i];
    myInFile11 >> lambda[11][i] >> counts[11][i];
    myInFile12 >> lambda[12][i] >> counts[12][i];
    myInFile13 >> lambda[13][i] >> counts[13][i];
    myInFile14 >> lambda[14][i] >> counts[14][i];
    myInFile15 >> lambda[15][i] >> counts[15][i];
    myInFile16 >> lambda[16][i] >> counts[16][i];
    myInFile17 >> lambda[17][i] >> counts[17][i];
    myInFile18 >> lambda[18][i] >> counts[18][i];
    myInFile19 >> lambda[19][i] >> counts[19][i];
    myInFile20 >> lambda[20][i] >> counts[20][i];
    myInFile21 >> lambda[21][i] >> counts[21][i];
    myInFile22 >> lambda[22][i] >> counts[22][i];
    myInFile23 >> lambda[23][i] >> counts[23][i];
    myInFile24 >> lambda[24][i] >> counts[24][i];
    myInFile25 >> lambda[25][i] >> counts[25][i];
    myInFile26 >> lambda[26][i] >> counts[26][i];
    myInFile27 >> lambda[27][i] >> counts[27][i];
    myInFile28 >> lambda[28][i] >> counts[28][i];
    myInFile29 >> lambda[29][i] >> counts[29][i];
    myInFile30 >> lambda[30][i] >> counts[30][i];
    myInFile31 >> lambda[31][i] >> counts[31][i];
    myInFile32 >> lambda[32][i] >> counts[32][i];
    myInFile33 >> lambda[33][i] >> counts[33][i];
    myInFile34 >> lambda[34][i] >> counts[34][i];
    myInFile35 >> lambda[35][i] >> counts[35][i];
    myInFile36 >> lambda[36][i] >> counts[36][i];
    myInFile37 >> lambda[37][i] >> counts[37][i];

    //cout << i << " : " << lambda[73][i] << "             " <<  counts[73][i] << endl;
    dummyError[i] = 0.0;
    statError[0][i] = sqrt(counts[0][i]);
    statError[1][i] = sqrt(counts[1][i]);
    statError[2][i] = sqrt(counts[2][i]);
    statError[3][i] = sqrt(counts[3][i]);
    statError[4][i] = sqrt(counts[4][i]);
    statError[5][i] = sqrt(counts[5][i]);
    statError[6][i] = sqrt(counts[6][i]);
    statError[7][i] = sqrt(counts[7][i]);
    statError[6][i] = sqrt(counts[8][i]);
    statError[9][i] = sqrt(counts[9][i]);
    statError[10][i] = sqrt(counts[10][i]);
    statError[11][i] = sqrt(counts[11][i]);
    statError[12][i] = sqrt(counts[12][i]);
    statError[13][i] = sqrt(counts[13][i]);
    statError[14][i] = sqrt(counts[14][i]);
    statError[15][i] = sqrt(counts[15][i]);
    statError[16][i] = sqrt(counts[16][i]);
    statError[17][i] = sqrt(counts[17][i]);
    statError[18][i] = sqrt(counts[18][i]);
    statError[19][i] = sqrt(counts[19][i]);
    statError[20][i] = sqrt(counts[20][i]);
    statError[21][i] = sqrt(counts[21][i]);
    statError[22][i] = sqrt(counts[22][i]);
    statError[23][i] = sqrt(counts[23][i]);
    statError[24][i] = sqrt(counts[24][i]);
    statError[25][i] = sqrt(counts[25][i]);
    statError[26][i] = sqrt(counts[26][i]);
    statError[27][i] = sqrt(counts[27][i]);
    statError[28][i] = sqrt(counts[28][i]);
    statError[29][i] = sqrt(counts[29][i]);
    statError[30][i] = sqrt(counts[30][i]);
    statError[31][i] = sqrt(counts[31][i]);
    statError[32][i] = sqrt(counts[32][i]);
    statError[33][i] = sqrt(counts[33][i]);
    statError[34][i] = sqrt(counts[34][i]);
    statError[35][i] = sqrt(counts[35][i]);
    statError[36][i] = sqrt(counts[36][i]);
    statError[37][i] = sqrt(counts[37][i]);
  }

  myInFile0.close();
  myInFile1.close();
  myInFile2.close();
  myInFile3.close();  
  myInFile4.close();
  myInFile5.close();
  myInFile6.close();
  myInFile7.close();
  myInFile8.close();
  myInFile9.close();
  myInFile10.close();
  myInFile11.close();
  myInFile12.close();
  myInFile13.close();
  myInFile14.close();
  myInFile15.close();
  myInFile16.close();
  myInFile17.close();
  myInFile18.close();
  myInFile19.close();
  myInFile20.close();
  myInFile21.close();
  myInFile22.close();
  myInFile23.close();
  myInFile24.close();
  myInFile25.close();
  myInFile26.close();
  myInFile27.close();
  myInFile28.close();
  myInFile29.close();
  myInFile30.close();
  myInFile31.close();
  myInFile32.close();
  myInFile33.close();
  myInFile34.close();
  myInFile35.close();
  myInFile36.close();
  myInFile37.close();

  const Int_t points_cal = 65;
  const Int_t points_cal_my = 1;
  float lambda_my[points_cal_my];
  float ref_nist_my[points_cal_my];
  lambda_my[0] = 175;
  ref_nist_my[0] = 0.50;
  float correction = 0.0/600; //0.04
 
  char INPUT_FILENAMEref[256];
  sprintf(INPUT_FILENAMEref,"../STAN-SSH-NIST_SN00400CERT00439.txt");
  fprintf(stderr, "My Input file name is: %s\n", INPUT_FILENAMEref);
  ifstream myInFileRef(INPUT_FILENAMEref);
  float lambda_cal[points_cal], reflectivity[points_cal], ref_my[points_cal];
  float dummyError_cal[points_cal];
  float dummyError_cal_my[points_cal_my];
  dummyError_cal_my[0] = 0.0;
  char header2[256];
  float temp[points_cal];
  for(int h = 0; h<1; h++) { //read the header info
    myInFileRef >> header2;
    //cout << header[h] << endl;
  }
  //cout << "Wavelength (nm) 	Counts" << endl;
  lambda_cal[0] = lambda_my[0]; 
  reflectivity[0] = ref_nist_my[0];
  ref_my[0] = reflectivity[0] - correction*600;//lambda_cal[0];
  for(int i=1;i<points_cal;i++) {
    myInFileRef >> lambda_cal[i] >> reflectivity[i] >> temp[i];
    //cout << i << " : " << lambda_cal[i] << "             " <<  reflectivity[i] << endl;
    dummyError_cal[i] = 0.0;
    ref_my[i] = reflectivity[i] - correction*600;//lambda_cal[i];
  }

  myInFileRef.close();


  //********************************************************************************************************************
  //Now produce raw data graph for unradiated varieties

  TCanvas *final_canvas1 = new TCanvas("final_canvas1","Reflectivity Study Graph",0,0,600,400);
  
  gStyle->SetOptStat(kFALSE);

  //  sprintf(graphname1,"#pi^{0} Photoproduction yield vs. #theta_{#pi^{0}} (%s)",histTitlePart);
  sprintf(graphname1,"");

  TH2F *hr1;
  hr1 = new TH2F("hr1",graphname1,1000,170.0,890.0,100,-200,70000);

  gStyle->SetTitleX(0.18);
  //  mass_ALL_th_e->SetTitleOffset(-10.0, "X");
  //  gStyle->SetLabelSize(0.05,"X");
  
  sprintf(xTitle,"Wavelength (nm)");  
  sprintf(yTitle,"Counts");  
  hr1->GetYaxis()->SetLabelColor(1);
  hr1->GetYaxis()->SetTitleColor(1);
  hr1->SetYTitle(yTitle);
  //    hr1->GetXaxis()->CenterTitle();
  //    hr1->GetYaxis()->CenterTitle();
  //hr1->GetYaxis()->SetTitleOffset(1.3);
  hr1->GetXaxis()->SetLabelColor(1);
  hr1->GetXaxis()->SetTitleColor(1);
  hr1->SetXTitle(xTitle);
  hr1->Draw();

  //  gr1 = new TGraphErrors(dndt_bins,theta_f, dn_f,dummyError,dn_f_err);
  //  gr1->SetMarkerColor(51);
  //  gr1->SetMarkerStyle(20);   
  //  gr1->SetMarkerSize(0.75);
  //  gr1->SetFillColor(0);
  //  gr1->Draw("P");

  //  gr2_ee = new TGraph(dndt_bins,theta_f, dn_f);

  TGraphErrors *gr1_nist = new TGraphErrors(points,lambda[std], counts[std], dummyError, statError[std]);
  gr1_nist->SetMarkerColor(kBlue);
  gr1_nist->SetMarkerStyle(20);   
  gr1_nist->SetMarkerSize(0.35);
  //  gr1_nist->SetFillColor(0);
  gr1_nist->Draw("P");

  TGraphErrors *gr2 = new TGraphErrors(points,lambda[14], counts[14], dummyError, statError[14]);
  gr2->SetMarkerColor(kRed);
  gr2->SetMarkerStyle(20);   
  gr2->SetMarkerSize(0.35);
  //  gr2->SetFillColor(0);
  gr2->Draw("P");

  TGraphErrors *gr3 = new TGraphErrors(points,lambda[2], counts[2], dummyError, statError[2]);
  gr3->SetMarkerColor(kRed+3);
  gr3->SetMarkerStyle(20);   
  gr3->SetMarkerSize(0.35);
  //  gr3->SetFillColor(0);
  gr3->Draw("P");

  TGraphErrors *gr4 = new TGraphErrors(points,lambda[4], counts[4], dummyError, statError[4]);
  gr4->SetMarkerColor(kRed+2);
  gr4->SetMarkerStyle(20);   
  gr4->SetMarkerSize(0.35);
  //  gr4->SetFillColor(0);
  gr4->Draw("P");

  TGraphErrors *gr5 = new TGraphErrors(points,lambda[3], counts[3], dummyError, statError[3]);
  gr5->SetMarkerColor(kRed-3);
  gr5->SetMarkerStyle(20);
  gr5->SetMarkerSize(0.35);
  //  gr5->SetFillColor(0);
  gr5->Draw("P");

  TGraphErrors *gr6 = new TGraphErrors(points,lambda[5], counts[5], dummyError, statError[5]);
  gr6->SetMarkerColor(kTeal);
  gr6->SetMarkerStyle(20);
  gr6->SetMarkerSize(0.35);
  //  gr6->SetFillColor(0);
  gr6->Draw("P");

  TGraphErrors *gr7 = new TGraphErrors(points,lambda[7], counts[7], dummyError, statError[7]);
  gr7->SetMarkerColor(kOrange);
  gr7->SetMarkerStyle(20);   
  gr7->SetMarkerSize(0.35);
  //  gr2->SetFillColor(0);
  gr7->Draw("P");

  TGraphErrors *gr8 = new TGraphErrors(points,lambda[12], counts[12], dummyError, statError[12]);
  gr8->SetMarkerColor(kGreen);
  gr8->SetMarkerStyle(20);   
  gr8->SetMarkerSize(0.35);
  //  gr2->SetFillColor(0);
  gr8->Draw("P");

  TGraphErrors *gr9 = new TGraphErrors(points,lambda[8], counts[8], dummyError, statError[8]);
  gr9->SetMarkerColor(kMagenta);
  gr9->SetMarkerStyle(20);   
  gr9->SetMarkerSize(0.35);
  //  gr2->SetFillColor(0);
  gr9->Draw("P");

  TGraphErrors *gr10 = new TGraphErrors(points,lambda[11], counts[11], dummyError, statError[11]);
  gr10->SetMarkerColor(kCyan);
  gr10->SetMarkerStyle(20);   
  gr10->SetMarkerSize(0.35);
  //  gr2->SetFillColor(0);
  gr10->Draw("P");

  //gr2->Draw("P");

  sprintf(GraphText1,"       Reflectivity Study: Raw data (~90 degree)");
  TPaveLabel *pt1 = new TPaveLabel(0.15,0.91, 0.80,0.97,GraphText1,"NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(1);
  pt1->SetTextSize(0.85);
  pt1->SetFillColor(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.75,0.84, 0.89,0.89, "Ocean Optics","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(1);
  pt1->SetTextSize(0.6);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();
  TPaveLabel *pt1 = new TPaveLabel(0.75,0.80, 0.89,0.86, "DH-2000","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(1);
  pt1->SetTextSize(0.5);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();
  TPaveLabel *pt1 = new TPaveLabel(0.75,0.765, 0.89,0.825, "light source","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(1);
  pt1->SetTextSize(0.58);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  //TDatime d;
  //  sprintf(GraphText1,"%s",d.AsString());
  //  TPaveText *pt1_0 = new TPaveText(0.61,0.71, 0.895,0.77,"NDC");
  //  pt1_0->AddText(GraphText1);
  //  pt1_0->SetBorderSize(0);
  //  pt1_0->SetTextColor(49);
  //  pt1_0->SetFillColor(0);
  //  pt1_0->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.15,0.84, 0.33,0.89, "Un-radiated","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(1);
  pt1->SetTextSize(0.7);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  //pt1->Draw();

  TLegend *leg1 = new TLegend(0.15,0.58,0.39,0.83);
  leg1->SetBorderSize(0);
  leg1->SetFillColor(0);
  leg1->SetFillStyle(0);
  leg1->AddEntry(gr1_nist,"NIST standard","pl");
  leg1->AddEntry(gr2,"Bogdan's 1mil Al. mylar","pl");
  leg1->AddEntry(gr3,"Dan's metalized BB film","pl");
  leg1->AddEntry(gr4,"my 1mil Al. mylar","pl");
  leg1->AddEntry(gr5,"my 2mil Al. mylar","pl");
  leg1->AddEntry(gr6,"Reynolds Al. foil","pl");
  leg1->AddEntry(gr7,"Anolux I","pl");
  leg1->AddEntry(gr8,"Anolux UVS","pl");
  leg1->AddEntry(gr9,"Anolux Miro IV","pl");
  leg1->AddEntry(gr10,"Miro 2000Ag (diffuse)","pl");

  leg1->Draw();

  sprintf(printname,"rawData1_%ddeg.pdf", angle);
  final_canvas1->Print(printname);

  //*************************************************************************************

  TCanvas *final_canvas2 = new TCanvas("final_canvas2","Reflectivity",0,0,600,400);
  
  gStyle->SetOptStat(kFALSE);

  //  sprintf(graphname1,"#pi^{0} Photoproduction yield vs. #theta_{#pi^{0}} (%s)",histTitlePart);
  sprintf(graphname1,"");

  TH2F *hr2;
  hr2 = new TH2F("hr2",graphname1,1000,170.0,890.0,100,0,1);

  gStyle->SetTitleX(0.18);
  //  mass_ALL_th_e->SetTitleOffset(-10.0, "X");
  //  gStyle->SetLabelSize(0.05,"X");
  
  sprintf(xTitle,"Wavelength (nm)");  
  sprintf(yTitle,"Reflectivity");  
  hr2->GetYaxis()->SetLabelColor(1);
  hr2->GetYaxis()->SetTitleColor(1);
  hr2->SetYTitle(yTitle);
  //    hr2->GetXaxis()->CenterTitle();
  //    hr2->GetYaxis()->CenterTitle();
  //hr2->GetYaxis()->SetTitleOffset(1.3);
  hr2->GetXaxis()->SetLabelColor(1);
  hr2->GetXaxis()->SetTitleColor(1);
  hr2->SetXTitle(xTitle);
  hr2->Draw();

  TBox *b = new TBox(170,0,250,1.0);
  b->SetFillStyle(3001);
  b->SetLineColor(0);
  b->SetFillColor(19);
  b->Draw();

  TGraphErrors *gr1_cal = new TGraphErrors(points_cal,lambda_cal,reflectivity,dummyError_cal,dummyError_cal);
  gr1_cal->SetMarkerColor(kBlue);
  gr1_cal->SetMarkerStyle(22);   
  gr1_cal->SetMarkerSize(0.75);
  //  gr1_cal->SetFillColor(0);
  gr1_cal->Draw("P");

  TGraphErrors *gr2_cal = new TGraphErrors(points_cal_my,lambda_my,ref_nist_my,dummyError_cal_my,dummyError_cal_my);
  gr2_cal->SetMarkerColor(kSpring+4);
  gr2_cal->SetMarkerStyle(21);   
  gr2_cal->SetMarkerSize(0.85);
  //  gr1_cal->SetFillColor(0);
  gr2_cal->Draw("P");

  //Make a spline of this data
  // use a cubic spline to smooth the graph
  TSpline3 *s = new TSpline3("grs",gr1_cal);
  s->SetLineColor(kRed);
  s->SetLineWidth(0.5);
  s->Draw("same");

  TLegend *leg1 = new TLegend(0.55,0.55,0.89,0.75);
  leg1->SetBorderSize(0);
  leg1->SetFillColor(0);
  leg1->SetFillStyle(0);
  leg1->AddEntry(gr1_cal,"data from NIST","p");
  leg1->AddEntry(gr2_cal,"my added point","p");
  leg1->AddEntry(s,"Spline Interpolation","l");
  leg1->Draw();

  //cout << "I am here" << endl;

  sprintf(GraphText1,"   Reflectivity: NIST Standard (84 degree)");
  TPaveLabel *pt2 = new TPaveLabel(0.15,0.91, 0.80,0.97,GraphText1,"NDC");
  pt2->SetBorderSize(0);
  pt2->SetTextColor(1);
  pt2->SetTextSize(0.85);
  pt2->SetFillColor(0);
  pt2->Draw();

  sprintf(printname,"plotNIST_%ddeg.pdf", angle);
  final_canvas2->Print(printname);

    TGraphErrors *gr1_cal_my = new TGraphErrors(points_cal,lambda_cal,ref_my,dummyError_cal,dummyError_cal);
  //Make a spline of this data
  // use a cubic spline to smooth the graph
  TSpline3 *s_my = new TSpline3("grs_my",gr1_cal_my);

  //********************************************************************************************************************

  float ref[files][points];
  float refError[files][points];

  for(int i=0;i<points;i++) {

    ref[0][i] = counts[0][i]/counts[std][i]*s_my->Eval(lambda[0][i]);    
    ref[1][i] = counts[1][i]/counts[std][i]*s_my->Eval(lambda[1][i]);    
    ref[2][i] = counts[2][i]/counts[std][i]*s_my->Eval(lambda[2][i]);    
    ref[3][i] = counts[3][i]/counts[std][i]*s_my->Eval(lambda[3][i]);
    ref[4][i] = counts[4][i]/counts[std][i]*s_my->Eval(lambda[4][i]);
    ref[5][i] = counts[5][i]/counts[std][i]*s_my->Eval(lambda[5][i]);
    ref[6][i] = counts[6][i]/counts[std][i]*s_my->Eval(lambda[6][i]);
    ref[7][i] = counts[7][i]/counts[std][i]*s_my->Eval(lambda[7][i]);
    ref[8][i] = counts[8][i]/counts[std][i]*s_my->Eval(lambda[8][i]);
    ref[9][i] = counts[9][i]/counts[std][i]*s_my->Eval(lambda[9][i]);
    ref[10][i] = counts[10][i]/counts[std][i]*s_my->Eval(lambda[10][i]);
    ref[11][i] = counts[11][i]/counts[std][i]*s_my->Eval(lambda[11][i]);
    ref[12][i] = counts[12][i]/counts[std][i]*s_my->Eval(lambda[12][i]);
    ref[13][i] = counts[13][i]/counts[std][i]*s_my->Eval(lambda[13][i]);
    ref[14][i] = counts[14][i]/counts[std][i]*s_my->Eval(lambda[14][i]);
    ref[15][i] = counts[15][i]/counts[std][i]*s_my->Eval(lambda[15][i]);
    ref[16][i] = counts[16][i]/counts[std][i]*s_my->Eval(lambda[16][i]);
    ref[17][i] = counts[17][i]/counts[std][i]*s_my->Eval(lambda[17][i]);
    ref[18][i] = counts[18][i]/counts[std][i]*s_my->Eval(lambda[18][i]);
    ref[19][i] = counts[19][i]/counts[std][i]*s_my->Eval(lambda[19][i]);
    ref[20][i] = counts[20][i]/counts[std][i]*s_my->Eval(lambda[20][i]);
    ref[21][i] = counts[21][i]/counts[std][i]*s_my->Eval(lambda[21][i]);
    ref[22][i] = counts[22][i]/counts[std][i]*s_my->Eval(lambda[22][i]);
    ref[23][i] = counts[23][i]/counts[std][i]*s_my->Eval(lambda[23][i]);
    ref[24][i] = counts[24][i]/counts[std][i]*s_my->Eval(lambda[24][i]);
    ref[25][i] = counts[25][i]/counts[std][i]*s_my->Eval(lambda[25][i]);
    ref[26][i] = counts[26][i]/counts[std][i]*s_my->Eval(lambda[26][i]);
    ref[27][i] = counts[27][i]/counts[std][i]*s_my->Eval(lambda[27][i]);
    ref[28][i] = counts[28][i]/counts[std][i]*s_my->Eval(lambda[28][i]);
    ref[29][i] = counts[29][i]/counts[std][i]*s_my->Eval(lambda[29][i]);
    ref[30][i] = counts[30][i]/counts[std][i]*s_my->Eval(lambda[30][i]);
    ref[31][i] = counts[31][i]/counts[std][i]*s_my->Eval(lambda[31][i]);
    ref[32][i] = counts[32][i]/counts[std][i]*s_my->Eval(lambda[32][i]);
    ref[33][i] = counts[33][i]/counts[std][i]*s_my->Eval(lambda[33][i]);
    ref[34][i] = counts[34][i]/counts[std][i]*s_my->Eval(lambda[34][i]);
    ref[35][i] = counts[35][i]/counts[std][i]*s_my->Eval(lambda[35][i]);
    ref[36][i] = counts[36][i]/counts[std][i]*s_my->Eval(lambda[36][i]);
    ref[37][i] = counts[37][i]/counts[std][i]*s_my->Eval(lambda[37][i]);

    ref[std][i] = s->Eval(lambda[std][i]);

    if(counts[0][i] > 0) {refError[0][i] = ref[0][i]/sqrt(counts[0][i]);}
    else {refError[0][i] = ref[0][i];}
    if(counts[1][i] > 0) {refError[1][i] = ref[1][i]/sqrt(counts[1][i]);}
    else {refError[1][i] = ref[1][i];}
    if(counts[2][i] > 0) {refError[2][i] = ref[2][i]/sqrt(counts[2][i]);}
    else {refError[2][i] = ref[2][i];}
    if(counts[3][i] > 0) {refError[3][i] = ref[3][i]/sqrt(counts[3][i]);}
    else {refError[3][i] = ref[3][i];}
    if(counts[4][i] > 0) {refError[4][i] = ref[4][i]/sqrt(counts[4][i]);}
    else {refError[4][i] = ref[4][i];}
    if(counts[5][i] > 0) {refError[5][i] = ref[5][i]/sqrt(counts[5][i]);}
    else {refError[5][i] = ref[5][i];}
    if(counts[6][i] > 0) {refError[6][i] = ref[6][i]/sqrt(counts[6][i]);}
    else {refError[6][i] = ref[6][i];}
    if(counts[7][i] > 0) {refError[7][i] = ref[7][i]/sqrt(counts[7][i]);}
    else {refError[7][i] = ref[7][i];}
    if(counts[8][i] > 0) {refError[8][i] = ref[8][i]/sqrt(counts[8][i]);}
    else {refError[8][i] = ref[8][i];}
    if(counts[9][i] > 0) {refError[9][i] = ref[9][i]/sqrt(counts[9][i]);}
    else {refError[9][i] = ref[9][i];}
    if(counts[10][i] > 0) {refError[10][i] = ref[10][i]/sqrt(counts[10][i]);}
    else {refError[10][i] = ref[10][i];}
    if(counts[11][i] > 0) {refError[11][i] = ref[11][i]/sqrt(counts[11][i]);}
    else {refError[11][i] = ref[11][i];}
    if(counts[12][i] > 0) {refError[12][i] = ref[12][i]/sqrt(counts[12][i]);}
    else {refError[12][i] = ref[12][i];}
    if(counts[13][i] > 0) {refError[13][i] = ref[13][i]/sqrt(counts[13][i]);}
    else {refError[13][i] = ref[13][i];}
    if(counts[14][i] > 0) {refError[14][i] = ref[14][i]/sqrt(counts[14][i]);}
    else {refError[14][i] = ref[14][i];}
    if(counts[15][i] > 0) {refError[15][i] = ref[15][i]/sqrt(counts[15][i]);}
    else {refError[15][i] = ref[15][i];}
    if(counts[16][i] > 0) {refError[16][i] = ref[16][i]/sqrt(counts[16][i]);}
    else {refError[16][i] = ref[16][i];}
    if(counts[17][i] > 0) {refError[17][i] = ref[17][i]/sqrt(counts[17][i]);}
    else {refError[17][i] = ref[17][i];}
    if(counts[18][i] > 0) {refError[18][i] = ref[18][i]/sqrt(counts[18][i]);}
    else {refError[18][i] = ref[18][i];}
    if(counts[19][i] > 0) {refError[19][i] = ref[19][i]/sqrt(counts[19][i]);}
    else {refError[19][i] = ref[19][i];}
    if(counts[20][i] > 0) {refError[20][i] = ref[20][i]/sqrt(counts[20][i]);}
    else {refError[20][i] = ref[20][i];}
    if(counts[21][i] > 0) {refError[21][i] = ref[21][i]/sqrt(counts[21][i]);}
    else {refError[21][i] = ref[21][i];}
    if(counts[22][i] > 0) {refError[22][i] = ref[22][i]/sqrt(counts[22][i]);}
    else {refError[22][i] = ref[22][i];}
    if(counts[23][i] > 0) {refError[23][i] = ref[23][i]/sqrt(counts[23][i]);}
    else {refError[23][i] = ref[23][i];}
    if(counts[24][i] > 0) {refError[24][i] = ref[24][i]/sqrt(counts[24][i]);}
    else {refError[24][i] = ref[24][i];}
    if(counts[25][i] > 0) {refError[25][i] = ref[25][i]/sqrt(counts[25][i]);}
    else {refError[25][i] = ref[25][i];}
    if(counts[26][i] > 0) {refError[26][i] = ref[26][i]/sqrt(counts[26][i]);}
    else {refError[26][i] = ref[26][i];}
    if(counts[27][i] > 0) {refError[27][i] = ref[27][i]/sqrt(counts[27][i]);}
    else {refError[27][i] = ref[27][i];}
    if(counts[28][i] > 0) {refError[28][i] = ref[28][i]/sqrt(counts[28][i]);}
    else {refError[28][i] = ref[28][i];}
    if(counts[29][i] > 0) {refError[29][i] = ref[29][i]/sqrt(counts[29][i]);}
    else {refError[29][i] = ref[29][i];}
    if(counts[30][i] > 0) {refError[30][i] = ref[30][i]/sqrt(counts[30][i]);}
    else {refError[30][i] = ref[30][i];}
    if(counts[31][i] > 0) {refError[31][i] = ref[31][i]/sqrt(counts[31][i]);}
    else {refError[31][i] = ref[31][i];}
    if(counts[32][i] > 0) {refError[32][i] = ref[32][i]/sqrt(counts[32][i]);}
    else {refError[32][i] = ref[32][i];}
    if(counts[33][i] > 0) {refError[33][i] = ref[33][i]/sqrt(counts[33][i]);}
    else {refError[33][i] = ref[33][i];}
    if(counts[34][i] > 0) {refError[34][i] = ref[34][i]/sqrt(counts[34][i]);}
    else {refError[34][i] = ref[34][i];}
    if(counts[35][i] > 0) {refError[35][i] = ref[35][i]/sqrt(counts[35][i]);}
    else {refError[35][i] = ref[35][i];}
    if(counts[36][i] > 0) {refError[36][i] = ref[36][i]/sqrt(counts[36][i]);}
    else {refError[36][i] = ref[36][i];}
    if(counts[37][i] > 0) {refError[37][i] = ref[37][i]/sqrt(counts[37][i]);}
    else {refError[37][i] = ref[37][i];}

  }

  //Now produce reflectivity graph for 90 degrees

  TCanvas *final_canvas3 = new TCanvas("final_canvas3","Reflectivity Study Graph",0,0,600,400);
  
  gStyle->SetOptStat(kFALSE);

  //  sprintf(graphname1,"#pi^{0} Photoproduction yield vs. #theta_{#pi^{0}} (%s)",histTitlePart);
  sprintf(graphname1,"");

  TH2F *hr3;
  hr3 = new TH2F("hr3",graphname1,1000,170.0,890.0,140,0.0,1.10);

  gStyle->SetTitleX(0.18);
  //  mass_ALL_th_e->SetTitleOffset(-10.0, "X");
  //  gStyle->SetLabelSize(0.05,"X");
  
  sprintf(xTitle,"Wavelength (nm)");  
  sprintf(yTitle,"Reflectivity");  
  hr3->GetYaxis()->SetLabelColor(1);
  hr3->GetYaxis()->SetTitleColor(1);
  hr3->SetYTitle(yTitle);
  //    hr1->GetXaxis()->CenterTitle();
  //    hr1->GetYaxis()->CenterTitle();
  //hr3->GetYaxis()->SetTitleOffset(1.3);
  hr3->GetXaxis()->SetLabelColor(1);
  hr3->GetXaxis()->SetTitleColor(1);
  hr3->SetXTitle(xTitle);
  hr3->Draw();

  TGraphErrors *gr1_ref_nist = new TGraphErrors(points,lambda[std], ref[std], dummyError, refError[std]);
  gr1_ref_nist->SetMarkerColor(kBlue);
  gr1_ref_nist->SetMarkerStyle(20);   
  gr1_ref_nist->SetMarkerSize(0.35);
  //  gr1_nist->SetFillColor(0);
  //gr1_ref_nist->SetLineColor(kBlue);
  gr1_ref_nist->Draw("P");

  TGraphErrors *gr2_ref = new TGraphErrors(points,lambda[14], ref[14], dummyError, refError[14]);
  gr2_ref->SetMarkerColor(kRed);
  gr2_ref->SetMarkerStyle(20);   
  gr2_ref->SetMarkerSize(0.35);
  //  gr2->SetFillColor(0);
  gr2_ref->Draw("P");

  TGraphErrors *gr3_ref = new TGraphErrors(points,lambda[2], ref[2], dummyError, refError[2]);
  gr3_ref->SetMarkerColor(kRed+3);
  gr3_ref->SetMarkerStyle(20);   
  gr3_ref->SetMarkerSize(0.35);
  //  gr3->SetFillColor(0);
  gr3_ref->Draw("P");

  TGraphErrors *gr4_ref = new TGraphErrors(points,lambda[4], ref[4], dummyError, refError[4]);
  gr4_ref->SetMarkerColor(kRed+2);
  gr4_ref->SetMarkerStyle(20);   
  gr4_ref->SetMarkerSize(0.35);
  //  gr4->SetFillColor(0);
  gr4_ref->Draw("P");

  TGraphErrors *gr5_ref = new TGraphErrors(points,lambda[3], ref[3], dummyError, refError[3]);
  gr5_ref->SetMarkerColor(kRed-3);
  gr5_ref->SetMarkerStyle(20);   
  gr5_ref->SetMarkerSize(0.35);
  //  gr5->SetFillColor(0);
  gr5_ref->Draw("P");

  TGraphErrors *gr6_ref = new TGraphErrors(points,lambda[5], ref[5], dummyError, refError[5]);
  gr6_ref->SetMarkerColor(kTeal);
  gr6_ref->SetMarkerStyle(20); 
  gr6_ref->SetMarkerSize(0.35);
  //  gr6->SetFillColor(0);
  gr6_ref->Draw("P");

  TGraphErrors *gr7_ref = new TGraphErrors(points,lambda[7], ref[7], dummyError, refError[7]);
  gr7_ref->SetMarkerColor(kOrange);
  gr7_ref->SetMarkerStyle(20); 
  gr7_ref->SetMarkerSize(0.35);
  //  gr7->SetFillColor(0);
  gr7_ref->Draw("P");

  TGraphErrors *gr8_ref = new TGraphErrors(points,lambda[12], ref[12], dummyError, refError[12]);
  gr8_ref->SetMarkerColor(kGreen);
  gr8_ref->SetMarkerStyle(20); 
  gr8_ref->SetMarkerSize(0.35);
  //  gr8->SetFillColor(0);
  gr8_ref->Draw("P");

  TGraphErrors *gr9_ref = new TGraphErrors(points,lambda[8], ref[8], dummyError, refError[8]);
  gr9_ref->SetMarkerColor(kMagenta);
  gr9_ref->SetMarkerStyle(20); 
  gr9_ref->SetMarkerSize(0.35);
  //  gr9->SetFillColor(0);
  gr9_ref->Draw("P");

  TGraphErrors *gr10_ref = new TGraphErrors(points,lambda[11], ref[11], dummyError, refError[11]);
  gr10_ref->SetMarkerColor(kCyan);
  gr10_ref->SetMarkerStyle(20); 
  gr10_ref->SetMarkerSize(0.35);
  //  gr9->SetFillColor(0);
  gr10_ref->Draw("P");

  sprintf(GraphText1,"Reflectivity (~90 degree)");
  TPaveLabel *pt1 = new TPaveLabel(0.15,0.91, 0.80,0.97,GraphText1,"NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(1);
  pt1->SetTextSize(0.85);
  pt1->SetFillColor(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.46, 0.89,0.50,"NIST Standard","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kBlue);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.42, 0.89,0.46,"Bogdan's Al. Mylar","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kRed);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.38, 0.89,0.42,"Dan's Al. Mylar (BB)","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kRed+3);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.34, 0.89,0.38,"my 1mil Al. Mylar","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kRed+2);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.30, 0.89,0.34,"my 2mil Al. Mylar","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kRed-3);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.26, 0.89,0.30,"Reynold's Al. Foil", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kTeal);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.22, 0.89,0.26,"Anolux I", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kOrange);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.18, 0.89,0.22,"Anolux UVS", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kGreen);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.14, 0.89,0.18,"Anolux MiroIV", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kMagenta);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.10, 0.89,0.14,"Miro 2000ag (Diffuse)", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kCyan);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TBox *b = new TBox(170,0,250,1.1);
  b->SetFillStyle(3001);
  b->SetLineColor(0);
  b->SetFillColor(19);
  b->Draw();

  sprintf(printname,"reflectivity_90deg.pdf");
  final_canvas3->Print(printname);


  //Now produce reflectivity graph for Anolux I at different angles

  TCanvas *final_canvas4 = new TCanvas("final_canvas4","Reflectivity Study Graph",0,0,600,400);
  
  gStyle->SetOptStat(kFALSE);

  //  sprintf(graphname1,"#pi^{0} Photoproduction yield vs. #theta_{#pi^{0}} (%s)",histTitlePart);
  sprintf(graphname1,"");

  TH2F *hr4;
  hr4 = new TH2F("hr4",graphname1,1000,170.0,890.0,140,0.0,1.10);

  gStyle->SetTitleX(0.18);
  //  mass_ALL_th_e->SetTitleOffset(-10.0, "X");
  //  gStyle->SetLabelSize(0.05,"X");
  
  sprintf(xTitle,"Wavelength (nm)");  
  sprintf(yTitle,"Reflectivity");  
  hr4->GetYaxis()->SetLabelColor(1);
  hr4->GetYaxis()->SetTitleColor(1);
  hr4->SetYTitle(yTitle);
  //    hr1->GetXaxis()->CenterTitle();
  //    hr1->GetYaxis()->CenterTitle();
  //hr3->GetYaxis()->SetTitleOffset(1.3);
  hr4->GetXaxis()->SetLabelColor(1);
  hr4->GetXaxis()->SetTitleColor(1);
  hr4->SetXTitle(xTitle);
  hr4->Draw();

  TGraphErrors *gr1_ref_nist = new TGraphErrors(points,lambda[std], ref[std], dummyError, refError[std]);
  gr1_ref_nist->SetMarkerColor(kBlue);
  gr1_ref_nist->SetMarkerStyle(20);   
  gr1_ref_nist->SetMarkerSize(0.35);
  //gr1_ref_nist->Draw("P");

  TGraphErrors *gr2_ref = new TGraphErrors(points,lambda[7], ref[7], dummyError, refError[7]);
  gr2_ref->SetMarkerColor(kOrange);
  gr2_ref->SetMarkerStyle(20);   
  gr2_ref->SetMarkerSize(0.35);
  //  gr2->SetFillColor(0);
  gr2_ref->Draw("P");

  TGraphErrors *gr3_ref = new TGraphErrors(points,lambda[20], ref[20], dummyError, refError[20]);
  gr3_ref->SetMarkerColor(kOrange+1);
  gr3_ref->SetMarkerStyle(20);   
  gr3_ref->SetMarkerSize(0.35);
  //  gr3->SetFillColor(0);
  gr3_ref->Draw("P");

  TGraphErrors *gr4_ref = new TGraphErrors(points,lambda[21], ref[21], dummyError, refError[21]);
  gr4_ref->SetMarkerColor(kOrange+4);
  gr4_ref->SetMarkerStyle(20);   
  gr4_ref->SetMarkerSize(0.35);
  //  gr4->SetFillColor(0);
  gr4_ref->Draw("P");

  TGraphErrors *gr5_ref = new TGraphErrors(points,lambda[22], ref[22], dummyError, refError[22]);
  gr5_ref->SetMarkerColor(kOrange+3);
  gr5_ref->SetMarkerStyle(20);   
  gr5_ref->SetMarkerSize(0.35);
  //  gr5->SetFillColor(0);
  gr5_ref->Draw("P");


  sprintf(GraphText1,"Reflectivity (Anolux I)");
  TPaveLabel *pt1 = new TPaveLabel(0.15,0.91, 0.80,0.97,GraphText1,"NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(1);
  pt1->SetTextSize(0.85);
  pt1->SetFillColor(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.35, 0.89,0.40,"90 degree","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kOrange);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.30, 0.89,0.35,"60 degree","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kOrange+1);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.25, 0.89,0.30,"45 degree", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kOrange+4);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.20, 0.89,0.25,"30 degree", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kOrange+3);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TBox *b = new TBox(170,0,250,1.1);
  b->SetFillStyle(3001);
  b->SetLineColor(0);
  b->SetFillColor(19);
  b->Draw();

  sprintf(printname,"reflectivity_anoluxI.pdf");
  final_canvas4->Print(printname);

  //*********************************************************************
  //Now produce reflectivity graph for Bogdan's Al. Mylar at different angles

  TCanvas *final_canvas5 = new TCanvas("final_canvas5","Reflectivity Study Graph",0,0,600,400);
  
  gStyle->SetOptStat(kFALSE);

  //  sprintf(graphname1,"#pi^{0} Photoproduction yield vs. #theta_{#pi^{0}} (%s)",histTitlePart);
  sprintf(graphname1,"");

  TH2F *hr5;
  hr5 = new TH2F("hr5",graphname1,1000,170.0,890.0,140,0.0,1.10);

  gStyle->SetTitleX(0.18);
  //  mass_ALL_th_e->SetTitleOffset(-10.0, "X");
  //  gStyle->SetLabelSize(0.05,"X");
  
  sprintf(xTitle,"Wavelength (nm)");  
  sprintf(yTitle,"Reflectivity");  
  hr5->GetYaxis()->SetLabelColor(1);
  hr5->GetYaxis()->SetTitleColor(1);
  hr5->SetYTitle(yTitle);
  //    hr1->GetXaxis()->CenterTitle();
  //    hr1->GetYaxis()->CenterTitle();
  //hr3->GetYaxis()->SetTitleOffset(1.3);
  hr5->GetXaxis()->SetLabelColor(1);
  hr5->GetXaxis()->SetTitleColor(1);
  hr5->SetXTitle(xTitle);
  hr5->Draw();

  TGraphErrors *gr1_ref_nist = new TGraphErrors(points,lambda[std], ref[std], dummyError, refError[std]);
  gr1_ref_nist->SetMarkerColor(kBlue);
  gr1_ref_nist->SetMarkerStyle(20);   
  gr1_ref_nist->SetMarkerSize(0.35);
  //gr1_ref_nist->Draw("P");

  TGraphErrors *gr2_ref = new TGraphErrors(points,lambda[14], ref[14], dummyError, refError[14]);
  gr2_ref->SetMarkerColor(kRed);
  gr2_ref->SetMarkerStyle(20);   
  gr2_ref->SetMarkerSize(0.35);
  //  gr2->SetFillColor(0);
  gr2_ref->Draw("P");

  TGraphErrors *gr3_ref = new TGraphErrors(points,lambda[32], ref[32], dummyError, refError[32]);
  gr3_ref->SetMarkerColor(kRed+1);
  gr3_ref->SetMarkerStyle(20);   
  gr3_ref->SetMarkerSize(0.35);
  //  gr3->SetFillColor(0);
  gr3_ref->Draw("P");

  TGraphErrors *gr4_ref = new TGraphErrors(points,lambda[33], ref[33], dummyError, refError[33]);
  gr4_ref->SetMarkerColor(kRed+3);
  gr4_ref->SetMarkerStyle(20);   
  gr4_ref->SetMarkerSize(0.35);
  //  gr4->SetFillColor(0);
  gr4_ref->Draw("P");

  TGraphErrors *gr5_ref = new TGraphErrors(points,lambda[34], ref[34], dummyError, refError[34]);
  gr5_ref->SetMarkerColor(kRed+4);
  gr5_ref->SetMarkerStyle(20);   
  gr5_ref->SetMarkerSize(0.35);
  //  gr5->SetFillColor(0);
  gr5_ref->Draw("P");


  sprintf(GraphText1,"Reflectivity: Bogdan's Al. Mylar (1 mil, single-sided)");
  TPaveLabel *pt1 = new TPaveLabel(0.15,0.91, 0.80,0.97,GraphText1,"NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(1);
  pt1->SetTextSize(0.85);
  pt1->SetFillColor(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.35, 0.89,0.40,"90 degree","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kRed);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.30, 0.89,0.35,"60 degree","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kRed+1);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.25, 0.89,0.30,"45 degree", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kRed+3);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.20, 0.89,0.25,"30 degree", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kRed+4);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TBox *b = new TBox(170,0,250,1.1);
  b->SetFillStyle(3001);
  b->SetLineColor(0);
  b->SetFillColor(19);
  b->Draw();

  sprintf(printname,"reflectivity_bogdanMylar.pdf");
  final_canvas5->Print(printname);

  //*********************************************************************
  //Now produce reflectivity graph for miroIV at different angles

  TCanvas *final_canvas6 = new TCanvas("final_canvas6","Reflectivity Study Graph",0,0,600,400);
  
  gStyle->SetOptStat(kFALSE);

  //  sprintf(graphname1,"#pi^{0} Photoproduction yield vs. #theta_{#pi^{0}} (%s)",histTitlePart);
  sprintf(graphname1,"");

  TH2F *hr6;
  hr6 = new TH2F("hr6",graphname1,1000,170.0,890.0,140,0.0,1.10);

  gStyle->SetTitleX(0.18);
  //  mass_ALL_th_e->SetTitleOffset(-10.0, "X");
  //  gStyle->SetLabelSize(0.05,"X");
  
  sprintf(xTitle,"Wavelength (nm)");  
  sprintf(yTitle,"Reflectivity");  
  hr6->GetYaxis()->SetLabelColor(1);
  hr6->GetYaxis()->SetTitleColor(1);
  hr6->SetYTitle(yTitle);
  //    hr1->GetXaxis()->CenterTitle();
  //    hr1->GetYaxis()->CenterTitle();
  //hr3->GetYaxis()->SetTitleOffset(1.3);
  hr6->GetXaxis()->SetLabelColor(1);
  hr6->GetXaxis()->SetTitleColor(1);
  hr6->SetXTitle(xTitle);
  hr6->Draw();

  TGraphErrors *gr1_ref_nist = new TGraphErrors(points,lambda[std], ref[std], dummyError, refError[std]);
  gr1_ref_nist->SetMarkerColor(kBlue);
  gr1_ref_nist->SetMarkerStyle(20);   
  gr1_ref_nist->SetMarkerSize(0.35);
  //gr1_ref_nist->Draw("P");

  TGraphErrors *gr2_ref = new TGraphErrors(points,lambda[8], ref[8], dummyError, refError[8]);
  gr2_ref->SetMarkerColor(kMagenta);
  gr2_ref->SetMarkerStyle(20);   
  gr2_ref->SetMarkerSize(0.35);
  //  gr2->SetFillColor(0);
  gr2_ref->Draw("P");

  TGraphErrors *gr3_ref = new TGraphErrors(points,lambda[26], ref[26], dummyError, refError[26]);
  gr3_ref->SetMarkerColor(kMagenta+1);
  gr3_ref->SetMarkerStyle(20);   
  gr3_ref->SetMarkerSize(0.35);
  //  gr3->SetFillColor(0);
  gr3_ref->Draw("P");

  TGraphErrors *gr4_ref = new TGraphErrors(points,lambda[27], ref[27], dummyError, refError[27]);
  gr4_ref->SetMarkerColor(kMagenta+3);
  gr4_ref->SetMarkerStyle(20);   
  gr4_ref->SetMarkerSize(0.35);
  //  gr4->SetFillColor(0);
  gr4_ref->Draw("P");

  TGraphErrors *gr5_ref = new TGraphErrors(points,lambda[28], ref[28], dummyError, refError[28]);
  gr5_ref->SetMarkerColor(kMagenta+4);
  gr5_ref->SetMarkerStyle(20);   
  gr5_ref->SetMarkerSize(0.35);
  //  gr5->SetFillColor(0);
  gr5_ref->Draw("P");


  sprintf(GraphText1,"Reflectivity (Anolux Miro IV)");
  TPaveLabel *pt1 = new TPaveLabel(0.15,0.91, 0.80,0.97,GraphText1,"NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(1);
  pt1->SetTextSize(0.85);
  pt1->SetFillColor(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.35, 0.89,0.40,"90 degree","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kMagenta);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.30, 0.89,0.35,"60 degree","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kMagenta+1);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.25, 0.89,0.30,"45 degree", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kMagenta+3);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.20, 0.89,0.25,"30 degree", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kMagenta+4);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TBox *b = new TBox(170,0,250,1.1);
  b->SetFillStyle(3001);
  b->SetLineColor(0);
  b->SetFillColor(19);
  b->Draw();

  sprintf(printname,"reflectivity_miroIV.pdf");
  final_canvas6->Print(printname);

  //*********************************************************************
  //Now produce reflectivity graph for aluminum Foil at different angles

  TCanvas *final_canvas7 = new TCanvas("final_canvas7","Reflectivity Study Graph",0,0,600,400);
  
  gStyle->SetOptStat(kFALSE);

  //  sprintf(graphname1,"#pi^{0} Photoproduction yield vs. #theta_{#pi^{0}} (%s)",histTitlePart);
  sprintf(graphname1,"");

  TH2F *hr7;
  hr7 = new TH2F("hr6",graphname1,1000,170.0,890.0,140,0.0,1.10);

  gStyle->SetTitleX(0.18);
  //  mass_ALL_th_e->SetTitleOffset(-10.0, "X");
  //  gStyle->SetLabelSize(0.05,"X");
  
  sprintf(xTitle,"Wavelength (nm)");  
  sprintf(yTitle,"Reflectivity");  
  hr7->GetYaxis()->SetLabelColor(1);
  hr7->GetYaxis()->SetTitleColor(1);
  hr7->SetYTitle(yTitle);
  //    hr1->GetXaxis()->CenterTitle();
  //    hr1->GetYaxis()->CenterTitle();
  //hr3->GetYaxis()->SetTitleOffset(1.3);
  hr7->GetXaxis()->SetLabelColor(1);
  hr7->GetXaxis()->SetTitleColor(1);
  hr7->SetXTitle(xTitle);
  hr7->Draw();

  TGraphErrors *gr1_ref_nist = new TGraphErrors(points,lambda[std], ref[std], dummyError, refError[std]);
  gr1_ref_nist->SetMarkerColor(kBlue);
  gr1_ref_nist->SetMarkerStyle(20);   
  gr1_ref_nist->SetMarkerSize(0.35);
  //gr1_ref_nist->Draw("P");

  TGraphErrors *gr2_ref = new TGraphErrors(points,lambda[5], ref[5], dummyError, refError[5]);
  gr2_ref->SetMarkerColor(kTeal);
  gr2_ref->SetMarkerStyle(20);   
  gr2_ref->SetMarkerSize(0.35);
  //  gr2->SetFillColor(0);
  gr2_ref->Draw("P");

  TGraphErrors *gr3_ref = new TGraphErrors(points,lambda[35], ref[35], dummyError, refError[35]);
  gr3_ref->SetMarkerColor(kTeal+1);
  gr3_ref->SetMarkerStyle(20);   
  gr3_ref->SetMarkerSize(0.35);
  //  gr3->SetFillColor(0);
  gr3_ref->Draw("P");

  TGraphErrors *gr4_ref = new TGraphErrors(points,lambda[36], ref[36], dummyError, refError[36]);
  gr4_ref->SetMarkerColor(kTeal+4);
  gr4_ref->SetMarkerStyle(20);   
  gr4_ref->SetMarkerSize(0.35);
  //  gr4->SetFillColor(0);
  gr4_ref->Draw("P");

  TGraphErrors *gr5_ref = new TGraphErrors(points,lambda[37], ref[37], dummyError, refError[37]);
  gr5_ref->SetMarkerColor(kTeal+3);
  gr5_ref->SetMarkerStyle(20);   
  gr5_ref->SetMarkerSize(0.35);
  //  gr5->SetFillColor(0);
  gr5_ref->Draw("P");


  sprintf(GraphText1,"Reflectivity: Reynolds Al. Foil (shiny-side)");
  TPaveLabel *pt1 = new TPaveLabel(0.15,0.91, 0.80,0.97,GraphText1,"NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(1);
  pt1->SetTextSize(0.85);
  pt1->SetFillColor(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.35, 0.89,0.40,"90 degree","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kTeal);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.30, 0.89,0.35,"60 degree","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kTeal+1);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.25, 0.89,0.30,"45 degree", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kTeal+4);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.20, 0.89,0.25,"30 degree", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kTeal+3);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TBox *b = new TBox(170,0,250,1.1);
  b->SetFillStyle(3001);
  b->SetLineColor(0);
  b->SetFillColor(19);
  b->Draw();

  sprintf(printname,"reflectivity_alFoil.pdf");
  final_canvas7->Print(printname);

  //*********************************************************************
  //Now produce reflectivity graph for my 1 mil Al.mylar at different angles

  TCanvas *final_canvas8 = new TCanvas("final_canvas8","Reflectivity Study Graph",0,0,600,400);
  
  gStyle->SetOptStat(kFALSE);

  //  sprintf(graphname1,"#pi^{0} Photoproduction yield vs. #theta_{#pi^{0}} (%s)",histTitlePart);
  sprintf(graphname1,"");

  TH2F *hr8;
  hr8 = new TH2F("hr6",graphname1,1000,170.0,890.0,140,0.0,1.10);

  gStyle->SetTitleX(0.18);
  //  mass_ALL_th_e->SetTitleOffset(-10.0, "X");
  //  gStyle->SetLabelSize(0.05,"X");
  
  sprintf(xTitle,"Wavelength (nm)");  
  sprintf(yTitle,"Reflectivity");  
  hr8->GetYaxis()->SetLabelColor(1);
  hr8->GetYaxis()->SetTitleColor(1);
  hr8->SetYTitle(yTitle);
  //    hr1->GetXaxis()->CenterTitle();
  //    hr1->GetYaxis()->CenterTitle();
  //hr3->GetYaxis()->SetTitleOffset(1.3);
  hr8->GetXaxis()->SetLabelColor(1);
  hr8->GetXaxis()->SetTitleColor(1);
  hr8->SetXTitle(xTitle);
  hr8->Draw();

  TGraphErrors *gr1_ref_nist = new TGraphErrors(points,lambda[std], ref[std], dummyError, refError[std]);
  gr1_ref_nist->SetMarkerColor(kBlue);
  gr1_ref_nist->SetMarkerStyle(20);   
  gr1_ref_nist->SetMarkerSize(0.35);
  //gr1_ref_nist->Draw("P");

  TGraphErrors *gr2_ref = new TGraphErrors(points,lambda[4], ref[4], dummyError, refError[4]);
  gr2_ref->SetMarkerColor(kRed);
  gr2_ref->SetMarkerStyle(20);   
  gr2_ref->SetMarkerSize(0.35);
  //  gr2->SetFillColor(0);
  gr2_ref->Draw("P");

  TGraphErrors *gr3_ref = new TGraphErrors(points,lambda[29], ref[29], dummyError, refError[29]);
  gr3_ref->SetMarkerColor(kRed+1);
  gr3_ref->SetMarkerStyle(20);   
  gr3_ref->SetMarkerSize(0.35);
  //  gr3->SetFillColor(0);
  gr3_ref->Draw("P");

  TGraphErrors *gr4_ref = new TGraphErrors(points,lambda[30], ref[30], dummyError, refError[30]);
  gr4_ref->SetMarkerColor(kRed+3);
  gr4_ref->SetMarkerStyle(20);   
  gr4_ref->SetMarkerSize(0.35);
  //  gr4->SetFillColor(0);
  gr4_ref->Draw("P");

  TGraphErrors *gr5_ref = new TGraphErrors(points,lambda[31], ref[31], dummyError, refError[31]);
  gr5_ref->SetMarkerColor(kRed+4);
  gr5_ref->SetMarkerStyle(20);   
  gr5_ref->SetMarkerSize(0.35);
  //  gr5->SetFillColor(0);
  gr5_ref->Draw("P");


  sprintf(GraphText1,"Reflectivity: my Al. mylar (1 mil, single-sided)");
  TPaveLabel *pt1 = new TPaveLabel(0.15,0.91, 0.80,0.97,GraphText1,"NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(1);
  pt1->SetTextSize(0.85);
  pt1->SetFillColor(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.35, 0.89,0.40,"90 degree","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kRed);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.30, 0.89,0.35,"60 degree","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kRed+1);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.25, 0.89,0.30,"45 degree", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kRed+3);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.20, 0.89,0.25,"30 degree", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kRed+4);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TBox *b = new TBox(170,0,250,1.1);
  b->SetFillStyle(3001);
  b->SetLineColor(0);
  b->SetFillColor(19);
  b->Draw();

  sprintf(printname,"reflectivity_my1minMylar.pdf");
  final_canvas8->Print(printname);

  //*********************************************************************
  //Now produce reflectivity graph for 4270 at different angles

  TCanvas *final_canvas9 = new TCanvas("final_canvas9","Reflectivity Study Graph",0,0,600,400);
  
  gStyle->SetOptStat(kFALSE);

  //  sprintf(graphname1,"#pi^{0} Photoproduction yield vs. #theta_{#pi^{0}} (%s)",histTitlePart);
  sprintf(graphname1,"");

  TH2F *hr9;
  hr9 = new TH2F("hr9",graphname1,1000,170.0,890.0,140,0.0,1.10);

  gStyle->SetTitleX(0.18);
  //  mass_ALL_th_e->SetTitleOffset(-10.0, "X");
  //  gStyle->SetLabelSize(0.05,"X");
  
  sprintf(xTitle,"Wavelength (nm)");  
  sprintf(yTitle,"Reflectivity");  
  hr9->GetYaxis()->SetLabelColor(1);
  hr9->GetYaxis()->SetTitleColor(1);
  hr9->SetYTitle(yTitle);
  //    hr1->GetXaxis()->CenterTitle();
  //    hr1->GetYaxis()->CenterTitle();
  //hr3->GetYaxis()->SetTitleOffset(1.3);
  hr9->GetXaxis()->SetLabelColor(1);
  hr9->GetXaxis()->SetTitleColor(1);
  hr9->SetXTitle(xTitle);
  hr9->Draw();

  TGraphErrors *gr1_ref_nist = new TGraphErrors(points,lambda[std], ref[std], dummyError, refError[std]);
  gr1_ref_nist->SetMarkerColor(kBlue);
  gr1_ref_nist->SetMarkerStyle(20);   
  gr1_ref_nist->SetMarkerSize(0.35);
  //gr1_ref_nist->Draw("P");

  TGraphErrors *gr2_ref = new TGraphErrors(points,lambda[4], ref[4], dummyError, refError[4]);
  gr2_ref->SetMarkerColor(kMagenta);
  gr2_ref->SetMarkerStyle(20);   
  gr2_ref->SetMarkerSize(0.35);
  //  gr2->SetFillColor(0);
  //gr2_ref->Draw("P");

  TGraphErrors *gr3_ref = new TGraphErrors(points,lambda[23], ref[23], dummyError, refError[23]);
  gr3_ref->SetMarkerColor(kMagenta+1);
  gr3_ref->SetMarkerStyle(20);   
  gr3_ref->SetMarkerSize(0.35);
  //  gr3->SetFillColor(0);
  gr3_ref->Draw("P");

  TGraphErrors *gr4_ref = new TGraphErrors(points,lambda[24], ref[24], dummyError, refError[24]);
  gr4_ref->SetMarkerColor(kMagenta+3);
  gr4_ref->SetMarkerStyle(20);   
  gr4_ref->SetMarkerSize(0.35);
  //  gr4->SetFillColor(0);
  gr4_ref->Draw("P");

  TGraphErrors *gr5_ref = new TGraphErrors(points,lambda[25], ref[25], dummyError, refError[25]);
  gr5_ref->SetMarkerColor(kMagenta+4);
  gr5_ref->SetMarkerStyle(20);   
  gr5_ref->SetMarkerSize(0.35);
  //  gr5->SetFillColor(0);
  gr5_ref->Draw("P");


  sprintf(GraphText1,"Reflectivity: Miro-silver 4270");
  TPaveLabel *pt1 = new TPaveLabel(0.15,0.91, 0.80,0.97,GraphText1,"NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(1);
  pt1->SetTextSize(0.85);
  pt1->SetFillColor(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.35, 0.89,0.40,"90 degree","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kMagenta);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  //pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.30, 0.89,0.35,"60 degree","NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kMagenta+1);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.25, 0.89,0.30,"45 degree", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kMagenta+3);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TPaveLabel *pt1 = new TPaveLabel(0.7,0.20, 0.89,0.25,"30 degree", "NDC");
  pt1->SetBorderSize(0);
  pt1->SetTextColor(kMagenta+4);
  pt1->SetTextSize(0.75);
  pt1->SetFillColor(0);
  pt1->SetFillStyle(0);
  pt1->Draw();

  TBox *b = new TBox(170,0,250,1.1);
  b->SetFillStyle(3001);
  b->SetLineColor(0);
  b->SetFillColor(19);
  b->Draw();

  sprintf(printname,"reflectivity_4270.pdf");
  final_canvas9->Print(printname);

  
  return 0;
}
